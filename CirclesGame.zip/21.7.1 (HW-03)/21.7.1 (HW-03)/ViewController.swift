//
//  ViewController.swift
//  21.7.1 (HW-03)
//
//  Created by Татьяна Биркле on 11.03.2024.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {
    
    @IBOutlet var currentView: [CustomFigure]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemGray4
    }
    
    @IBAction func panAction(_ gesture: UIPanGestureRecognizer) {
        
        let gestureTranslation = gesture.translation(in: view)
        guard let gestureView = gesture.view else {return}
        
        gestureView.center = CGPoint (x: gestureView.center.x + gestureTranslation.x,
                                      y: gestureView.center.y + gestureTranslation.y)
        
        gesture.setTranslation(.zero, in: view)
        
        guard gesture.state == .ended    else {return}
        print("Custom Figure panned")
        
        for i in 0...currentView.count-1 {
            let currentViewX = currentView[i].customView.frame.minX
            let currentViewY = currentView[i].customView.frame.minY
            let currentViewFrame = currentView[i].frame
            
            for x in Int(currentViewFrame.minX)...Int(currentViewFrame.maxX){
                for y in Int(currentViewFrame.minY)...Int(currentViewFrame.maxY){
                        if Int(gestureView.frame.origin.x) == x && Int(gestureView.frame.origin.y) == y {
                            
                            gestureView.isHidden = true
                            
                            let changedViewFrame = CGRect(x: currentViewX, y: currentViewY, width: currentView[i].customView.frame.width + 20, height: currentView[i].customView.frame.height + 20)
                            currentView[i].customView.frame = changedViewFrame
                            currentView[i].customView.layer.cornerRadius = changedViewFrame.width / 2
                            currentView[i].customView.backgroundColor = .blue
                       
                        }
                    }
                }
            }
        }
    }

        
    

