//
//  ViewController.swift
//  21.7.1 (HW-03)
//
//  Created by Татьяна Биркле on 11.03.2024.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {
    
    @IBOutlet var currentView: [CustomFigure]!
    
    @IBOutlet var playingFieldView: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemGray4
    }
    
    @IBAction func panAction(_ gesture: UIPanGestureRecognizer) {
        
        
        
        let state = gesture.state
        var isPositionUpdated = true
        guard let gestureView = gesture.view else {return}
        
        if state == .changed{
            let gestureTranslation = gesture.translation(in: view)
            
            gestureView.center = CGPoint (x: gestureView.center.x + gestureTranslation.x,
                                          y: gestureView.center.y + gestureTranslation.y)
            
            gesture.setTranslation(.zero, in: view)
            
            if gestureView.frame.minY <= playingFieldView.bounds.minY {
                isPositionUpdated = false
                gestureView.center = CGPoint(
                    x: gestureView.center.x,
                    y: gestureView.frame.height / 2)
            }
            
            if gestureView.frame.minX <= playingFieldView.bounds.minX {
                isPositionUpdated = false
                gestureView.center = CGPoint(
                    x: gestureView.frame.width / 2,
                    y: gestureView.center.y)
            }
            if gestureView.frame.maxY >= playingFieldView.bounds.maxY {
                isPositionUpdated = false
                gestureView.center = CGPoint(
                    x: gestureView.center.x,
                    y: self.playingFieldView.frame.height - (gestureView.frame.height / 2))
            }
            if gestureView.frame.maxX >= playingFieldView.bounds.maxX {
                isPositionUpdated = false
                gestureView.center = CGPoint(
                    x: self.playingFieldView.frame.width - (gestureView.frame.width / 2),
                    y: gestureView.center.y)
            }
        }
        
        if state == .ended {

            for i in 0...currentView.count-1 {
            let currentViewFrame = currentView[i].frame
                for x in Int(currentViewFrame.minX)...Int(currentViewFrame.maxX){
                    for y in Int(currentViewFrame.minY)...Int(currentViewFrame.maxY){
                        if Int(gestureView.frame.origin.x) == x && Int(gestureView.frame.origin.y) == y {
                            
                            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 3, options: .curveEaseOut) { [self] in
                                currentView[i].customView.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
                                self.currentView[i].customView.backgroundColor = .blue
                                currentView[i].customView.layer.cornerRadius = currentView[i].frame.width / 2
                                
                                gestureView.transform.a = 0
                                gestureView.transform.b = 0
                            
                            }
                        }
                    }
                }
            }
        }
    }
}
        
    

